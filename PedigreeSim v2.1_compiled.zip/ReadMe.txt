In order to run PedigreeSim from the command prompt,
make sure that the working directory contains a copy
of the PedigreeSim.jar file and the lib directory.

At the command prompt, type 

java -jar PedigreeSim.jar

or a variation on this, as discussed in the manual.